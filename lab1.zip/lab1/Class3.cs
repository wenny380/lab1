﻿using System;

public class exo3
{
	public int num;

	public exo3(int num1)
	{
		num = num1;
	}

	public void fibonacci()
    {
		int n1 = 0, n2 = 1, n3;

		Console.WriteLine(n1);
		Console.WriteLine(n2);

		for (int i = 2; i<num; i++)
        {
			n3 = n1 + n2;
			Console.WriteLine(n3);
			n1 = n2;
			n2 = n3;

        }

    }

}

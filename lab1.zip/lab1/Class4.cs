﻿using System;

public class exo4
{
	private int nombre;
	public exo4(int nomb)
	{
		nombre = nomb;
	}

	public void factorial()
    {
		int i, fa = 1;
		for(i=1; i<=nombre; i++)
        {
			fa = fa * i;
        }
		Console.WriteLine("Factorial of " + nombre + " is: " + fa);
    }
}

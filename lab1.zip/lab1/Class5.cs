﻿using System;

public class exo5
{
	public exo5()
	{
	}

	public void primeNumbers()
    {
		Console.WriteLine("Enter a number");

		int n = int.Parse(Console.ReadLine());
		bool[] A = new bool[n];

	
		Console.WriteLine("All the numbers");
		for (int i = 2; i < n; i++)
		{
			A[i] = true;
			Console.Write(" "+ i);
	}

	
		
		for (int i = 2; i<Math.Sqrt(n) + 1; ++i)
    {
	if (A[i])
	{
		for (int j = i* i; j<n; j += i)
		{
			A[j] = false;
		}
	}
    }
   Console.WriteLine();
		
		Console.WriteLine("The prime numbers");
		for (int i = 2; i < n; i++)
       {
	    if (A[i])
		Console.Write(" " +  i);
       }
		Console.WriteLine();
	}



	}
	

﻿using System;

public class exo1
{
	public exo1()
	{

	}
	public void argument(string[] ag)
    {
		
        if (ag.Length <= 0)
        {
			Console.WriteLine("No argument found");
		}
        else
        {
			for(int i=0; i<ag.Length; i++)
            {
				Console.WriteLine("the argument: "+ i+ " is " + ag[i]);
			}
			
			
		}
		

	}
}

﻿using System;

namespace lab1
{
    class Program
    {
        static void Main(string[] args)
        {
            int Exit;
            Console.Write("Menu \n 1. Press 1 for the first exercice \n 2 for the second\n 3 for the third\n 4 for the fourth \n 5 for the fith \n 0 to quit the program\n");
            Exit = int.Parse(Console.ReadLine());
            while (Exit!= 0)
            {
                if (Exit == 1)
                {
                    exo1 first = new exo1();
                    first.argument(args);
                }
                else if (Exit == 2)
                {
                    exo2 bis = new exo2();
                    bis.bissextile();
                }
                else if(Exit == 3)
                {
                    int number;
                    Console.WriteLine("Enter a number ");
                    number = int.Parse(Console.ReadLine());

                    exo3 fi = new exo3(number);
                    fi.fibonacci();
                }
                else if(Exit == 4)
                {
                    int chiffre;
                    Console.WriteLine("Enter a number ");
                    chiffre = int.Parse(Console.ReadLine());

                    exo4 factis = new exo4(chiffre);
                    factis.factorial();

                }
                else if (Exit == 5)
                {
                    exo5 prime = new exo5();
                    prime.primeNumbers();
                }
                    Console.Write("Menu \n 1. Press 1 for the first exercice \n 2 for the second\n 3 for the third\n 4 for the fourth \n 5 for the fith \n 0 to quit the program\n");
                Exit = int.Parse(Console.ReadLine());
            }
           
        }
    }
}
